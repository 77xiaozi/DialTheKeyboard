//
//  ViewController.m
//  拨号盘
//
//  Created by zyh on 16/6/12.
//  Copyright © 2016年 zyh. All rights reserved.
//
#define SELFVIEWBGC      [UIColor colorWithRed:247.0/255.0 green:245.0/255.0 blue:243.0/255 alpha:1.0];
#import "XMDialViewController.h"
#import "XMNumCell.h"
#import "XMNumData.h"
#import "Masonry.h"
#import "XMShowNumView.h"

@interface XMDialViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,XMShowNumViewDelegate>
@property (nonatomic,strong) UICollectionView *xmDialCollectionView; //拨号界面
@property (nonatomic,strong) UITableView *resultTableView; //显示搜索结果
@property (nonatomic,strong) XMShowNumView *numview;//显示输入的view

@end

@implementation XMDialViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self creatView];
}

#pragma mark 创建视图
-(void)creatView{
    __weak typeof(self)weakSelf = self;
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    //创建搜索table
    self.resultTableView = [[UITableView alloc]init];
    self.resultTableView.separatorStyle = 0;
    [self.view addSubview:self.resultTableView];
    [self.resultTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakSelf.view).with.offset(45);
        make.left.equalTo(weakSelf.view);
        make.size.mas_equalTo(CGSizeMake(KSCREENW, 70 KSCALE));
    }];
    //创建输入框
    self.numview = [[XMShowNumView alloc]init];
    self.numview.delegate = self;
    [self.view addSubview:self.numview];
    [self.numview mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakSelf.resultTableView.mas_bottom);
        make.left.equalTo(weakSelf.view);
        make.right.equalTo(weakSelf.view);
        make.height.mas_equalTo(@(62 KSCALE));
    }];
    //创建拨号界面
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc]init];
        flowLayout.itemSize = CGSizeMake(62 KSCALE ,62 KSCALE);
        flowLayout.minimumLineSpacing = 20 KSCALE;
        flowLayout.sectionInset = UIEdgeInsetsMake(20 KSCALE,62 KSCALE, 0,62 KSCALE);
        _xmDialCollectionView = [[UICollectionView alloc]initWithFrame:CGRectZero collectionViewLayout:flowLayout];
        [_xmDialCollectionView registerClass:[XMNumCell class] forCellWithReuseIdentifier:@"cell"];
        _xmDialCollectionView.dataSource = self;
        _xmDialCollectionView.backgroundColor = SELFVIEWBGC;
        [self.view addSubview:_xmDialCollectionView];
       [_xmDialCollectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakSelf.view);
        make.top.equalTo(weakSelf.numview.mas_bottom);
        make.width.mas_equalTo(@(KSCREENW));
        make.bottom.equalTo(weakSelf.view).with.offset(-20);
    }];
        UIButton *call = [UIButton buttonWithType:UIButtonTypeCustom];
        [call setBackgroundImage:[UIImage imageNamed:@"Key13"] forState:UIControlStateNormal];
        [call addTarget:self action:@selector(phoneCall) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:call];
         [call mas_makeConstraints:^(MASConstraintMaker *make) {
             make.centerX.equalTo(weakSelf.view);
             make.bottom.equalTo(weakSelf.view).with.offset(-30 KSCALE);
             make.size.mas_equalTo(CGSizeMake(86 KSCALE, 86 KSCALE));
         }];
    
}

#pragma mark UICollectionView delegate datasource
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 12;
}
-(UICollectionViewCell*)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    XMNumData *data =  [[XMNumData alloc]init];
    [data getData:indexPath.row];
    XMNumCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath ];
    cell.data = data;
    //点击拨号盘事件
    cell.numBlock = ^(){
        NSString *text = self.numview.inputNumberLabel.text;
        [self.numview.inputNumberLabel setText:[text stringByAppendingString:data.num]];
        [self.numview.delBtn setHidden:NO];
        
    };
    return cell;
}

#pragma mark 拨打电话
-(void)phoneCall{
  
}
#pragma mark  实现XMShowNumViewDelegate  删除输入的号码
-(void)deleteAll{
    [self.numview.inputNumberLabel setText:@""];
     self.numview.delBtn.hidden = YES;
}
-(void)deleteOneByOne{
    NSString *text = self.numview.inputNumberLabel.text;
    if (text.length > 0) {
       text = [text substringToIndex:text.length -1];
        [self.numview.inputNumberLabel setText:text];
    }else{
        self.numview.delBtn.hidden = YES;
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
